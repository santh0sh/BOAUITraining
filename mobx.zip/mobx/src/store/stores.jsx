import AuthStore from './auth.store'

const stores = {
    authStore: new AuthStore()
};
export default stores;
