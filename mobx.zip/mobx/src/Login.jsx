import React from "react";
import { Button, Form, Grid, Header, Segment } from 'semantic-ui-react'

import { inject, observer } from "mobx-react";


@inject("authStore")
@observer
class Login extends React.Component {

    constructor(props) {

        super(props)

        this.state = {
            username: '',
            password: '',
        }
    }
    // const[user, setUser] = useState({
    //     username: '',
    //     password: '',
    // });
    onSubmit = async e => {
        this.props.history.push('/Home');

        this.props.authStore.setLoggedInStatus(true);
        this.props.authStore.setLoggedInUser(this.state.username);

    };
    onInputChange = e => {
        this.setState({ ...this.state, [e.target.name]: e.target.value })
    };
    render() {

        return (
            <Grid textAlign='center' style={{ height: '100vh' }} verticalAlign='middle' >
                <Grid.Column style={{ maxWidth: 450 }}>
                    <Header as='h2' textAlign='center'>
                        Log-in
                         {/* {this.props.exampleStore2.email} */}

                    </Header>
exampleStore2                    <Form size='large'
                        onSubmit={this.onSubmit.bind(this)}>
                        {/* onSubmit={e => this.onSubmit(e)}> */}
                        <Segment stacked>
                            <Form.Input fluid icon='user'
                                iconPosition='left' placeholder='User Name'
                                onChange={e => this.onInputChange(e)}
                                name="username"

                            />
                            <Form.Input
                                fluid
                                icon='lock'
                                iconPosition='left'
                                placeholder='Password'
                                type='password'
                                name="password"
                                onChange={e => this.onInputChange(e)}
                            />



                            {/* <Button color='olive' fluid size='large'>
                                Login
          </Button> */}
                            {/* <Button onClick={() => { this.props.history.replace('/AddUser') }}>
                                Register 
</Button>*/}
                            <Button.Group>
                                <Button content="Login" positive
                                />

                            </Button.Group>

                        </Segment>
                    </Form>
                </Grid.Column>
            </Grid >
        )
    }

};

export default Login;