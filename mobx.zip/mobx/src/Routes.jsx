import React from 'react';
import { Route, Switch, withRouter } from 'react-router-dom';
import Login from './Login';
import { inject, observer } from "mobx-react";
import Home from './home';

@inject("authStore")
@observer
class Routes extends React.Component {

    render() {
        return (

            <div>

                <Switch>
                    <Route exact path="/login" component={Login} />
                    <Route exact path="/Home" component={Home} />
                    <Route exact path="/" component={Login} />


                </Switch>
            </div >
        );
    }
};
export default withRouter(Routes);
