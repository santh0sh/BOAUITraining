import React from 'react';
import { inject, observer } from "mobx-react";

@inject("authStore")
@observer
class Home extends React.Component {


    render() {

        return (
            <h1>hi  {this.props.authStore.loggedinUser} Welcome !</h1>
        )
    }
}
export default Home;
