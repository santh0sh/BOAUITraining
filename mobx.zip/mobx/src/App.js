import logo from './logo.svg';
import './App.css';
import { Provider } from"mobx-react";
import stores from './store/stores'
import { BrowserRouter } from 'react-router-dom';
import Routes from "./Routes";
function App() {
  return (
      <Provider{...stores}>
        <div  className="App">
          <BrowserRouter>
            <Routes/>
          </BrowserRouter>
        </div>
      </Provider>
  );
}

export default App;
